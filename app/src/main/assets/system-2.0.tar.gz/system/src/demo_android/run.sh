#Script to start the Andoid app

#'am' is found on most/all devices.. i hope..
am start -a android.intent.action.MAIN -n org.me.androiddemo/.MainActivity

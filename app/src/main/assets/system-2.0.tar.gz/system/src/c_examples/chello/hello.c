/*
 * A simple Hello world c app
 */

#include<stdio.h>

int main(){
	printf("Hello World!\n");
	return 0;
}

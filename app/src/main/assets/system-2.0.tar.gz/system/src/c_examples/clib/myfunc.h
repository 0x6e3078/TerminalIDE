/*
 * Declaration of my function
 */

extern void mySpecialFunction(char *zSometext);



#include <stdio.h>
#include "myfunc.h"

void mySpecialFunction(char* zText){
	printf("My Special Function : %s\n", zText);	
}

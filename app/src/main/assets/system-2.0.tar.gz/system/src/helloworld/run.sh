#Run script for hello world
java -jar hello.jar hello


//Demo of a large command line application
package org.demo;

public class name {

	public name(){}
	
	public static String getHello(){
		return "Hello you!!";
	}
}

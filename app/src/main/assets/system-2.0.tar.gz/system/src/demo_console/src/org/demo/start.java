//Demo of a large command line application

package org.demo;

import org.library.libfunc;

public class start {

	public static void main(String[] zArgs){
		System.out.println("Starting demo_console");	
	
		System.out.println(name.getHello());

		//Check library is working
		System.out.println(libfunc.getMessage());
	}


}

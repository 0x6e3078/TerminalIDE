//A demo Java Libraryi

package org.library;

public class libfunc{
	public static String getMessage(){
		return "This IS the message..!";	
	}
}

Here you will find a collection of example apps

java_examples :-

	Study the build.sh / install.sh / run.sh scripts to understand what is happening.

	helloworld 	- The classic
	demo_lib 	- A library that is used by the other two apps
	demo_console 	- A full command line application which uses libs
	demo_android 	- A complete Android application
	
	'cd' into the folders and run ./builder.sh

	then either ./run.sh or ./install.sh for the Android app.

	Copy the folders into your ~/projects/ folder to create your own apps.

	There is a ./builerpro.sh script in the demo_ apps. This uses proguard in the build process.

c_examples
	
	These come with a Makefile, and how to compile them is all explained in the HELP.
	
	READ. ALL. THE. HELP..

Enjoy.

